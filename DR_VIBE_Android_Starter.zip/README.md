# DR VIBE — Android starter

This is the first buildable Flutter starter for DR VIBE. It includes:
- Original DR VIBE dark theme and navigation shell
- Vertical short-video feed prototype
- One active player per visible feed item (basic lifecycle handling)
- GitHub Actions workflow to build a release APK
- Optional Supabase initialization through build-time values

## Build on GitHub
1. Create a GitHub repository named `dr-vibe`.
2. Upload the contents of this ZIP (the files inside the folder, not the ZIP itself).
3. Open **Actions** and run **Build DR VIBE Android APK**, or push to `main`.
4. Open the successful workflow run and download `dr-vibe-release-apk` under Artifacts.

## Supabase setup
Create a Supabase project. In Project Settings → API, copy the Project URL and anon/public key.
For a local build, pass:
`--dart-define=SUPABASE_URL=YOUR_PROJECT_URL --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY`

Never put a service-role key, database password, admin password, or payment secret in the Android app.
The anon key is intended for client use only when database Row Level Security (RLS) policies are correctly configured.

## Important status
This is a starter prototype, not a finished production social network. Login, uploads, comments, messaging, live video, payments, AI tools, moderation, admin dashboard, CDN integration, analytics, and production security still need implementation and testing. Demo video URLs are placeholders for feed testing.

## Smooth playback notes
The prototype pauses non-active players and disposes each item's player when removed. For production, implement a bounded player/preload manager (current + next item only), adaptive HLS/DASH renditions, CDN delivery, poster thumbnails, upload transcoding, retry logic, and device/network-aware quality selection. No app can guarantee zero buffering on every device or network.
