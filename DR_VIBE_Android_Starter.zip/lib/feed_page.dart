import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final PageController _pageController = PageController();
  int _activeIndex = 0;

  // Demo-only public sample clips. Replace with videos delivered by your backend/CDN.
  final List<VideoPost> posts = const [
    VideoPost(
      url: 'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
      creator: '@drvibe',
      caption: 'Welcome to a new way to discover what you love. #DRVIBE',
      likes: '12.8K',
    ),
    VideoPost(
      url: 'https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4',
      creator: '@creator_one',
      caption: 'Create. Share. Discover. #Vibe',
      likes: '8.4K',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            scrollDirection: Axis.vertical,
            itemCount: posts.length,
            onPageChanged: (index) => setState(() => _activeIndex = index),
            itemBuilder: (context, index) => VideoFeedItem(
              key: ValueKey(posts[index].url),
              post: posts[index],
              isActive: index == _activeIndex,
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              child: Row(
                children: [
                  const Text(
                    'DR VIBE',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2),
                  ),
                  const Spacer(),
                  TextButton(onPressed: () {}, child: const Text('Following')),
                  TextButton(onPressed: () {}, child: const Text('For You')),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: NavigationBar(
                backgroundColor: const Color(0xEE10131D),
                destinations: const [
                  NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
                  NavigationDestination(icon: Icon(Icons.search), label: 'Discover'),
                  NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'Create'),
                  NavigationDestination(icon: Icon(Icons.people_outline), label: 'Rooms'),
                  NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
                ],
                selectedIndex: 0,
                onDestinationSelected: (_) {},
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class VideoPost {
  final String url;
  final String creator;
  final String caption;
  final String likes;

  const VideoPost({
    required this.url,
    required this.creator,
    required this.caption,
    required this.likes,
  });
}

class VideoFeedItem extends StatefulWidget {
  final VideoPost post;
  final bool isActive;

  const VideoFeedItem({
    super.key,
    required this.post,
    required this.isActive,
  });

  @override
  State<VideoFeedItem> createState() => _VideoFeedItemState();
}

class _VideoFeedItemState extends State<VideoFeedItem> {
  late final VideoPlayerController _controller;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.post.url));
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _controller.initialize();
      await _controller.setLooping(true);
      if (!mounted) return;
      setState(() => _ready = true);
      if (widget.isActive) await _controller.play();
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void didUpdateWidget(covariant VideoFeedItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.isActive != widget.isActive && _ready) {
      widget.isActive ? _controller.play() : _controller.pause();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return VisibilityDetector(
      key: Key('video-${widget.post.url}'),
      onVisibilityChanged: (info) {
        if (!_ready) return;
        if (info.visibleFraction > 0.75 && widget.isActive) {
          _controller.play();
        } else {
          _controller.pause();
        }
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: const Color(0xFF171A25)),
          if (_ready)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size.width,
                height: _controller.value.size.height,
                child: VideoPlayer(_controller),
              ),
            )
          else if (!_failed)
            const Center(child: CircularProgressIndicator())
          else
            const Center(child: Text('Video could not be loaded')),
          Positioned(
            left: 18,
            right: 78,
            bottom: 112,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.post.creator, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(widget.post.caption, style: const TextStyle(fontSize: 14)),
              ],
            ),
          ),
          Positioned(
            right: 14,
            bottom: 150,
            child: Column(
              children: [
                const Icon(Icons.favorite, size: 30),
                Text(widget.post.likes),
                const SizedBox(height: 22),
                const Icon(Icons.mode_comment_outlined, size: 30),
                const Text('Comment'),
                const SizedBox(height: 22),
                const Icon(Icons.share_outlined, size: 30),
                const Text('Share'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
